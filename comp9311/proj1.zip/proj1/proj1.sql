-- comp9311 19s1 Project 1
--
-- MyMyUNSW Solutions


-- Q1:
create or replace view Q1(unswid, longname)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q2:
create or replace view Q2(unswid,name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q3:
create or replace view Q3(unswid, name)
as 
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q4:
create or replace view Q4(code,name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

--Q5:
create or replace view Q5(code,name,semester)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q6:
create or replace view Q6(num1, num2, num3)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q7:
create or replace view Q7(name, school, email, starting, num_subjects)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q8: 
create or replace view Q8(subject)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q9:
create or replace view Q9(year,num,unit)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q10:
create or replace view Q10(unswid,name,avg_mark)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q11:
create or replace view Q11(unswid, name, academic_standing)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q12:
create or replace view Q12(code, name, year, s1_ps_rate, s2_ps_rate)
as
--... SQL statements, possibly using other views/functions defined by you ...
;
